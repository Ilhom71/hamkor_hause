const toggle = document.querySelector('.menu-toggle');
const navigation = document.querySelector('.navigation');
function closeMenu() {
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-label', 'Menyuni ochish');
  navigation.classList.remove('is-open');
}
toggle.addEventListener('click', () => {
  const opened = toggle.getAttribute('aria-expanded') !== 'true';
  toggle.setAttribute('aria-expanded', String(opened));
  toggle.setAttribute('aria-label', opened ? 'Menyuni yopish' : 'Menyuni ochish');
  navigation.classList.toggle('is-open', opened);
});
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
document.addEventListener('click', event => { if (!event.target.closest('.header-inner')) closeMenu(); });
const gallery = document.querySelector('#gallery-dialog');
document.querySelectorAll('[data-image]').forEach(button => button.addEventListener('click', () => {
  const image = document.querySelector('#gallery-image');
  image.src = button.dataset.image;
  image.alt = button.dataset.title;
  document.querySelector('#gallery-title').textContent = button.dataset.title;
  gallery.showModal();
}));
document.querySelector('.dialog-close').addEventListener('click', () => gallery.close());
gallery.addEventListener('click', event => { if (event.target === gallery) gallery.close(); });
gallery.addEventListener('close', () => document.body.classList.remove('dialog-open'));
document.querySelectorAll('[data-image]').forEach(button => button.addEventListener('click', () => document.body.classList.add('dialog-open')));
document.querySelector('#year').textContent = new Date().getFullYear();
